function pair = swap(a, b)
    % swaps 2 numbers and returns as a cell
    pair = num2cell([b,a]);